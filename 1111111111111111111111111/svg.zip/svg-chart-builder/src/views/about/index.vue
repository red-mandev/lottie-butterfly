<template>
  <div class="about">
    <img alt="Vue logo" src="../../assets/images/logo.png" />
    <h1>SVG Builder</h1>
    <h3>Vue3</h3>
    <h3>Pinia</h3>
    <h3>D3.js</h3>
  </div>
</template>

<script>
export default {
  name: "AboutPage",
};
</script>
