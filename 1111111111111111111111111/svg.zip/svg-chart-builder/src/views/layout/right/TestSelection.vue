<template>
  <v-btn @click="increase">
    {{ store.getCounter }}
  </v-btn>
</template>

<script setup>
import { testStore } from "@/stores/test";
import { ref, computed } from "vue";

const store = testStore();
const increase = () => {
  store.increase();
}
</script>