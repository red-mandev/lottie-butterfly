<template>
  <div style="padding: 15px 10px; text-align: left">
    <SectionManage />
  </div>
</template>

<script setup>
import SectionManage from "@/views/home/components/SectionManage.vue";
</script>