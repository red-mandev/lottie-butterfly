import { defineStore } from "pinia";
import { ref, computed } from "vue";

export const testStore = defineStore("testStore", () => {
  const counter = ref(0);
  const increase = () => {
    counter.value++;
  };

  const getCounter = computed(() => counter);
  return { counter, increase, getCounter };
});
