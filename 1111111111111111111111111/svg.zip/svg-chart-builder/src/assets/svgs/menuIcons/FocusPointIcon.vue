<template>
  <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 20 20"
    style="enable-background: new 0 0 20 20" xml:space="preserve">
    <g>
      <circle cx="10" cy="10" r="9" fill="none" stroke="#000" stroke-width="1">
      </circle>
      <circle cx="10" cy="10" r="5" fill="none" stroke="#000" stroke-width="1">
      </circle>
    </g>
  </svg>
</template>
