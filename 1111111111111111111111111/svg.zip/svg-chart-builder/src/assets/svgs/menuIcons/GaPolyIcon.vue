<template>
  <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 32 28"
    style="enable-background:new 0 0 32 28;" xml:space="preserve">
    <g>
      <path class="st0" d="M10.8,18.6c1.7,0,3-0.7,4-1.5v-4.2h-4.2v1.5h2.5v2c-0.6,0.4-1.4,0.7-2.4,0.7c-1.9,0-3.3-1.5-3.3-3.5l0,0
		c0-1.8,1.4-3.5,3.2-3.5c1.2,0,1.9,0.4,2.8,1.1l1.1-1.3c-1-0.8-2.1-1.4-3.7-1.4c-2.9,0-5.1,2.2-5.1,5l0,0
		C5.7,16.5,7.8,18.6,10.8,18.6z" />
      <path class="st0"
        d="M19,16.1h4.6l1,2.4h1.8L22,8.6h-1.5l-4.3,9.9H18L19,16.1z M21.3,10.7l1.7,3.9h-3.3L21.3,10.7z" />
    </g>
    <path class="st0"
      d="M23.2,1.4L30.4,14l-7.2,12.6H8.8L1.6,14L8.8,1.4H23.2 M24,0H8L0,14l8,14h16l8-14L24,0L24,0z" />
  </svg>
</template>