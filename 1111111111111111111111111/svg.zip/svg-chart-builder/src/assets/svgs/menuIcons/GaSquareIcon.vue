<template>
  <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 20 20"
    style="enable-background: new 0 0 20 20" xml:space="preserve">
    <g>
      <path d="M0,0v20h20V0H0z M19,19H1V1h18V19z" />
      <path
        d="M6.2,13.6c1.2,0,2.2-0.5,2.9-1.1v-3h-3v1.1h1.8V12c-0.4,0.3-1,0.5-1.7,0.5c-1.4,0-2.4-1.1-2.4-2.5v0c0-1.3,1-2.5,2.3-2.5
		c0.9,0,1.4,0.3,2,0.8l0.8-0.9c-0.7-0.6-1.5-1-2.7-1C4.1,6.4,2.5,8,2.5,10v0C2.5,12.1,4,13.6,6.2,13.6z" />
      <path
        d="M12.1,11.8h3.3l0.7,1.7h1.3l-3.1-7.1h-1.1l-3.1,7.1h1.3L12.1,11.8z M13.8,7.9l1.2,2.8h-2.4L13.8,7.9z" />
    </g>
  </svg>
</template>
