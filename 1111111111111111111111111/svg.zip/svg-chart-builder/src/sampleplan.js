export default {
  sampleplan: {
    name: "My Seating Chart",
    categories: [],
    sections: [],
    zones: [
      {
        name: "Ground floor",
        position: {
          x: 0,
          y: 0,
        },
        rows: [],
        areas: [],
      },
    ],
    size: {
      width: 900,
      height: 900,
    },
    point: {
      x: 0,
      y: 0,
    },
    mode: false,
  },
};
